from flask import Flask , render_template
from flask_migrate import Migrate
from models import db 
from controllers.auth import login_manager , auth_bp
from werkzeug.security import generate_password_hash
from controllers.dashboard import dashboard_bp  
from controllers.subject import subject_bp 
from controllers.chapter import chapter_bp
from controllers.quizz import quizz_bp
from controllers.question import question_bp
from controllers.scores import scores_bp



app = Flask(__name__)


app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///quizmaster.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = "quiz_secret"


db.init_app(app) 
login_manager.init_app(app) 

migrate = Migrate(app , db) 

app.register_blueprint(auth_bp, url_prefix="/auth")
app.register_blueprint(dashboard_bp, url_prefix="/dashboard")
app.register_blueprint(subject_bp, url_prefix="/subject")
app.register_blueprint(chapter_bp, url_prefix="/chapter")   
app.register_blueprint(quizz_bp, url_prefix = "/quizz") 
app.register_blueprint(question_bp, url_prefix = "/question") 
app.register_blueprint(scores_bp, url_prefix = "/score")  


with app.app_context():
    from models.users import Users
    db.create_all()   


    admin = Users.query.filter_by(email = "admin@quizmaster.com").first()  
    
    
    if not admin:
        admin = Users(
                name="Admin",
                email="admin@quizmaster.com",
                password=generate_password_hash("admin@123"),
                role="admin",
                qualification = "Admin"
            ) 
        db.session.add(admin)
        db.session.commit() 


@app.route("/")
def home():
    return render_template("home.html")        

if __name__ == "__main__":
    app.run(debug = True)    