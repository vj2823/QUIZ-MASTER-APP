from . import db


class Subjects(db.Model):
    __tablename__ = "subjects"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    description = db.Column(db.String(255), nullable = False)
    chapters = db.relationship('Chapters', backref='subject', lazy=True , cascade="all, delete-orphan") 

    def __repr__(self):
        return f"<Subject {self.name}>"  

 
