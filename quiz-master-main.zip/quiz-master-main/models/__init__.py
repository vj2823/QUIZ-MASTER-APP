from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

from .users import Users
from .subjects import Subjects 
from .chapters import Chapters
from .quizzes import Quizzes
from .questions import Questions 
from .scores import Scores