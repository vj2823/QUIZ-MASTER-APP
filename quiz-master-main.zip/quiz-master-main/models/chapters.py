from . import db

class Chapters(db.Model):
    __tablename__ = "chapters"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.id'), nullable=False)

    quizzes = db.relationship('Quizzes', backref='chapter', lazy=True , cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Chapter {self.name}>"   
 