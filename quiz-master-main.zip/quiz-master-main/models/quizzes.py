from . import db 

from datetime import datetime


class Quizzes(db.Model):
    __tablename__ = "quizzes"

    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapters.id'), nullable=False)
    date_of_quiz = db.Column(db.Date, nullable=False, default=datetime.now()) 
    time_duration = db.Column(db.String(10), nullable=False)  
    remarks = db.Column(db.Text, nullable=True)
    num_questions = db.Column(db.Integer , default = 0) 

    questions = db.relationship('Questions', backref='quiz', lazy=True , cascade = "all, delete-orphan")
    scores = db.relationship('Scores', backref='quiz', lazy=True, cascade = "all, delete-orphan") 

    def __repr__(self):
        return f"<Quiz {self.id}>"   
