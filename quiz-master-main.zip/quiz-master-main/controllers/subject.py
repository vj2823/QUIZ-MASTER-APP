from flask import Blueprint, render_template, flash , redirect , url_for , request
from flask_login import login_required , current_user
from models import db
from models.subjects import Subjects

subject_bp = Blueprint("subject", __name__) 
 

@subject_bp.route("/add_subject", methods = ["POST", "GET"])
@login_required
def add_subject():
    if current_user.role != "admin":
        flash("Access denied! Admins only.", "danger")
        return redirect(url_for("dashboard.admin_dashboard"))
    
    if request.method == "POST":
        name = request.form.get("name")
        description = request.form.get("description")

        if not name or not description:
                flash("All fields are required!", "danger")
                return redirect(url_for("subject.add_subject"))  

        new_subject = Subjects(name=name, description=description)
        db.session.add(new_subject)
        db.session.commit()  

        flash("Subject added successfully!", "success")
        return redirect(url_for("dashboard.admin_dashboard"))  

    return render_template("add_subject.html") 

@subject_bp.route('/edit_subject/<int:subject_id>', methods = ["POST", "GET"])  
@login_required
def edit_subject(subject_id):
     if current_user.role != "admin":
        flash("Access denied! Admins only.", "danger")
        return redirect(url_for("dashboard.admin_dashboard"))
     
     subject = Subjects.query.get(subject_id)

     if not subject:
          flash("No Subject found with the id", "danger")
          return redirect(url_for("dashboard.admin_dashboard"))   
     
     if request.method == "POST":
          name = request.form.get("name")
          description = request.form.get("description")

          if not name and not description:
               flash("Please provide atleast one data to edit", "warning") 
               return redirect(url_for("subject.edit_subject", subject_id = subject_id)) 
          
          if name:
            subject.name = name

          if description:
            subject.description = description

          db.session.commit()
          flash("Subject updated successfully!", "success")
          return redirect(url_for("dashboard.admin_dashboard")) 
     
     return render_template('edit_subject.html', subject = subject) 


@subject_bp.route("/delete_subject/<int:subject_id>")
@login_required
def delete_subject(subject_id):
    if current_user.role != "admin":
        flash("Access Denied", "danger")
        return render_template(url_for('auth.login'))
    
    subject = Subjects.query.get(subject_id) 

    if not subject:
        flash("No chapter found with the id", "danger")

    db.session.delete(subject)
    db.session.commit()

    return redirect(url_for('dashboard.admin_dashboard')) 
        