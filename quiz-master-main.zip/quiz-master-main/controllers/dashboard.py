from flask import Blueprint, render_template , jsonify
from flask_login import login_required , current_user
from models import db
from models.subjects import Subjects
from models.quizzes import Quizzes
from models.chapters import Chapters
from models.scores import Scores
from sqlalchemy import asc

dashboard_bp = Blueprint("dashboard", __name__)
 
@dashboard_bp.route("/admin")
@login_required
def admin_dashboard():
    subjects = Subjects.query.all()
    return render_template("admin_dashboard.html", subjects = subjects)  

@dashboard_bp.route("/user")
@login_required
def user_dashboard():
    quizzes = Quizzes.query.join(Chapters).join(Subjects).order_by(asc(Quizzes.date_of_quiz)).all()
    return render_template("user_dashboard.html" , current_user = current_user , quizzes = quizzes)   


@dashboard_bp.route('/dashboard/summary') 
@login_required
def summary():
    return render_template('summary.html')

@dashboard_bp.route('/api/summary_data') 
@login_required
def summary_data():
    subjects = Subjects.query.all()
    
    data = {
        'subjects': [subject.name for subject in subjects],
        'scores': []
    }

    for subject in subjects:
        # Get all chapters related to the subject 
        chapters = Chapters.query.filter_by(subject_id=subject.id).all()

        # Collect all quiz IDs for the subject
        quiz_ids = [
            quiz.id for chapter in chapters 
            for quiz in Quizzes.query.filter_by(chapter_id=chapter.id).all()
        ]

        # Fetch highest score for the quizzes in this subject
        highest_score = db.session.query(db.func.max(Scores.total_scored))\
                                  .filter(Scores.quiz_id.in_(quiz_ids))\
                                  .scalar() or 0

        data['scores'].append(highest_score)

    return jsonify(data)     
  
