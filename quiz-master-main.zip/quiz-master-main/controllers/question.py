from flask import Blueprint, render_template, flash , redirect , url_for , request
from flask_login import login_required , current_user
from models import db
from models.subjects import Subjects
from models.questions import Questions
from models.chapters import Chapters
from models.quizzes import Quizzes


question_bp = Blueprint("question", __name__)

@question_bp.route('/add_question/<int:quiz_id>', methods = ["POST", "GET"])
def add_question(quiz_id):
    quiz = Quizzes.query.get_or_404(quiz_id)

    if request.method == "POST":
        question_statement = request.form.get("question_statement")
        option1 = request.form.get("option1")
        option2 = request.form.get("option2")
        option3 = request.form.get("option3")
        option4 = request.form.get("option4")
        correct_option = request.form.get("correct_option")

        if not question_statement or not option1 or not option2 or not option3 or not option4 or not correct_option:
            flash("Please fill all required fields!", "danger")
            return redirect(url_for("quizz.add_question", quiz_id=quiz_id))
        
        new_question = Questions(
            quiz_id=quiz_id,
            question_statement=question_statement,
            option1=option1,
            option2=option2,
            option3=option3,
            option4=option4,
            correct_option=correct_option
        )

        db.session.add(new_question)
        quiz.num_questions += 1

        db.session.commit()

        flash("Question added successfully!", "success")
        return redirect(url_for("question.questions", quiz_id=quiz_id))


    return render_template("add_question.html", quiz = quiz) 


# Displays all the questions inside a particular quizz
@question_bp.route('/list/<int:quiz_id>', methods = ["GET"])
def questions(quiz_id):
    quiz  = Quizzes.query.get(quiz_id)

    if not quiz:
        flash("Quiz Not Found with the id", 'danger')
        return render_template(url_for('quiz.quiz_list'))

    questions = Questions.query.filter_by(quiz_id=quiz.id).all()

    return render_template("questions.html", questions = questions , quiz = quiz) 


@question_bp.route('/edit_question/<int:question_id>', methods = ["POST", "GET"])
def edit_question(question_id):
    question =  Questions.query.get_or_404(question_id)

    if request.method == "POST":
        question_statement = request.form.get("question_statement")
        option1 = request.form.get("option1")
        option2 = request.form.get("option2")
        option3 = request.form.get("option3")
        option4 = request.form.get("option4")
        correct_option = request.form.get("correct_option")

        if not question_statement and not option1 and not option2 and not option3 and not option4 and not correct_option:
            flash("Please edit atleast one of the fields", "danger")
            return redirect(url_for("question.edit_question", question_id=question_id))
        
        if question_statement:
            question.question_statement = question_statement

        if option1:
            question.option1 = option1

        if option2:
            question.option2 = option2

        if option3:
            question.option3 = option3    

        if option4:
            question.option4 = option4

        if correct_option:
            question.correct_option = correct_option           
        

        db.session.commit()
        

        flash("Question edited successfully!", "success")
        return redirect(url_for("question.questions", quiz_id=question.quiz_id))


    return render_template("edit_question.html", question = question)   

@question_bp.route("/delete_question/<int:question_id>", methods = ["GET"])
@login_required
def delete_question(question_id):
    if current_user.role != "admin":
        flash("Access Denied", "danger")
        return render_template(url_for('auth.login'))
    
    question = Questions.query.get(question_id) 

    quiz_id = question.quiz_id

    if not question:
        flash("No question found with the id", "danger")

    db.session.delete(question)
    db.session.commit()

    return redirect(url_for('question.questions', quiz_id = quiz_id))   

