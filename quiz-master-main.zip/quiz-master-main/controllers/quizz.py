from flask import Blueprint, render_template, flash , redirect , url_for , request
from flask_login import login_required , current_user
from models import db
from models.chapters import Chapters
from models.subjects import Subjects
from models.quizzes import Quizzes
from models.questions import Questions
from models.scores import Scores
from datetime import datetime

quizz_bp = Blueprint("quizz", __name__) 
 

# Form to add a new quiz in a chapter
@quizz_bp.route("/add_quiz/<int:chapter_id>", methods = ["POST", "GET"])
@login_required
def add_quiz(chapter_id): 
    if current_user.role != "admin":
        flash("Access Denied!. Admins Only")
        return redirect(url_for('dashboard.admin_dashboard'))
    
    chapter = Chapters.query.get(chapter_id) 
    subject = Subjects.query.get(chapter.subject_id) 

    if not chapter:
        flash("No Chapter Found")
        return redirect(url_for('dashboard.admin_dashboard')) 
    
    if not subject:
        flash("No Subject Found")
        return redirect(url_for('dashboard.admin_dashboard'))
    
    if request.method == "POST":
        date_of_quiz = request.form.get('date_of_quiz')
        time_duration = request.form.get('time_duration')
        remarks = request.form.get('remarks')

        if not date_of_quiz or not time_duration: 
            flash("Date and Duration is required!", "danger")
            return redirect(url_for("dashboard.admin_dashboard"))  
        
        new_quiz = Quizzes(
            chapter_id=chapter_id,
            date_of_quiz=datetime.strptime(date_of_quiz, '%Y-%m-%d'),
            time_duration=time_duration,
            remarks=remarks
        )

        db.session.add(new_quiz)
        db.session.commit() 

        flash("Quiz added successfully!", "success")
        return redirect(url_for('quizz.quiz_list', chapter_id=chapter.id))    
    
    return render_template('add_quiz.html', chapter=chapter, subject=subject)       


# Displays all the quizzes of a chapter

@quizz_bp.route("/quiz_list/<int:chapter_id>", methods = ["GET"])
def quiz_list(chapter_id):
    chapter = Chapters.query.get(chapter_id)

    if not chapter:
        flash("Chapter Not Found with the id", 'danger')
        return render_template(url_for('dashboard.admin_dashboard')) 
    
    subject = Subjects.query.get(chapter.subject_id)
    if not subject:
        flash("Subject Not Found with the associated chapter id", 'danger')
        return render_template(url_for('dashboard.admin_dashboard')) 
    
    quizzes = Quizzes.query.filter_by(chapter_id = chapter_id).all()
    

    return render_template("quiz.html", chapter = chapter , subject = subject , quizzes = quizzes) 


@quizz_bp.route("/read_quiz/<int:quiz_id>", methods = ["GET"])
@login_required
def read_quiz(quiz_id):
    quiz = Quizzes.query.join(Chapters).join(Subjects)\
                        .filter(Quizzes.id == quiz_id)\
                        .first_or_404()

    return render_template("quiz_details.html", quiz = quiz) 


@quizz_bp.route("/start_quiz/<int:quiz_id>", methods=["GET", "POST"])
@login_required
def start_quiz(quiz_id):
    quiz = Quizzes.query.get_or_404(quiz_id)
    print("quiz", quiz)
    questions = Questions.query.filter_by(quiz_id=quiz_id).all()
    print("questions", questions) 

    if request.method == "POST":
        user_answers = request.form

        print("answers",user_answers) 

        score = 0
        total_questions = len(questions)

        for question in questions:
            correct_answer = question.correct_option
            print("correct_answer", correct_answer)
            user_answer = user_answers.get(f"question_{question.id}")
            print("user_answer", user_answer) 

            if user_answer == correct_answer:
                score += 1

        new_score = Scores(quiz_id=quiz.id, user_id=current_user.id, total_scored=score)
        db.session.add(new_score)
        db.session.commit()

        return redirect(url_for("quizz.quiz_result", quiz_id=quiz.id, score=score, total=total_questions))

    return render_template("quiz_attempt.html", quiz=quiz, questions=questions)


@quizz_bp.route("/quiz_result/<int:quiz_id>/<int:score>/<int:total>", methods=["GET"])
@login_required
def quiz_result(quiz_id, score, total):
    quiz = Quizzes.query.get_or_404(quiz_id)
    return render_template("quiz_result.html", quiz=quiz, score=score, total=total) 


@quizz_bp.route("/admin/quizzes", methods=["GET"])
@login_required
def view_quizzes():
    if current_user.role != "admin":
        flash("Access Denied!. Admins Only")
        return redirect(url_for('dashboard.admin_dashboard'))
    
    all_quizzes = (
        db.session.query(Quizzes, Chapters)
        .join(Chapters, Quizzes.chapter_id == Chapters.id)
        .all()
    )
    
    return render_template("admin_quizzes.html", all_quizzes=all_quizzes)   




      