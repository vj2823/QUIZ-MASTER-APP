from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, login_required, logout_user, LoginManager, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db
from models.users import Users 



auth_bp = Blueprint("auth",__name__)

login_manager = LoginManager()
login_manager.login_view = "auth.login"


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        user = Users.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            flash("Login successful!", "success")

            if user.role == "admin":
                return redirect(url_for("dashboard.admin_dashboard"))
            else:
                return redirect(url_for("dashboard.user_dashboard"))
        else:
            flash("Invalid email or password!", "danger")

    return render_template("login.html")


@auth_bp.route('/register', methods = ["GET" , "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        password = request.form.get("password")
        qualification = request.form.get("qualification") 
        hashed_password = generate_password_hash(password)
        
        user = Users(name=name, email=email, password=hashed_password, role="user" , qualification = qualification)
        db.session.add(user)
        db.session.commit()

        flash("Registration successful! Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html")

@login_manager.user_loader
def load_user(user_id):
    return Users.query.get(int(user_id))

@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Logged out successfully!", "info")
    return redirect(url_for("auth.login")) 
