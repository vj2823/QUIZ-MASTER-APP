from flask import Blueprint, render_template, flash , redirect , url_for , request
from flask_login import login_required , current_user
from models import db
from models.chapters import Chapters
from models.subjects import Subjects

chapter_bp = Blueprint("chapter", __name__) 
 

@chapter_bp.route("/add_chapter/<int:subject_id>", methods = ["POST", "GET"])
@login_required
def add_chapter(subject_id):
    if current_user.role != "admin":
        flash("Access Denied!. Admins Only")
        return redirect(url_for('dashboard.admin_dashboard'))
    
    subject = Subjects.query.get(subject_id)

    if not subject:
        flash("No Subject Found")
        return redirect(url_for('dashboard.admin_dashboard')) 
    
    if request.method == "POST":
        name = request.form.get("name")
        description = request.form.get("description")

        if not name or not description: 
            flash("Chapter name and Description is required!", "danger")
            return redirect(url_for("chapter.add_chapter", subject_id=subject_id)) 
        
        new_chapter = Chapters(name=name, description=description, subject_id=subject_id)
        db.session.add(new_chapter)
        db.session.commit()

        flash("Chapter added successfully!", "success")
        return redirect(url_for("dashboard.admin_dashboard")) 
    
    return render_template("add_chapter.html", subject = subject)   


@chapter_bp.route('/edit_chapter/<int:chapter_id>', methods = ["POST","PUT", "GET"])
@login_required
def edit_chapter(chapter_id):
    if current_user.role != "admin":
        flash("Access Denied", "danger")
        return render_template(url_for('auth.login'))
    
    chapter = Chapters.query.get(chapter_id)

    if not chapter:
        flash("No chapter found with the id", "danger")

    if request.method == "POST":
        name = request.form.get("name")
        description = request.form.get("description")

        if not name and not description:
            flash("Please provide at least a name or description to update.", "warning")
            return render_template("edit_chapter.html", chapter=chapter)

        if name:
            chapter.name = name

        if description:
            chapter.description = description

        db.session.commit()
        flash("Chapter updated successfully!", "success")
        return redirect(url_for('dashboard.admin_dashboard')) 

    return render_template("edit_chapter.html", chapter = chapter)      

    
@chapter_bp.route("/delete_chapter/<int:chapter_id>", methods = ["GET"])
@login_required
def delete_chapter(chapter_id):
    if current_user.role != "admin":
        flash("Access Denied", "danger")
        return render_template(url_for('auth.login'))
    
    chapter = Chapters.query.get(chapter_id) 

    if not chapter:
        flash("No chapter found with the id", "danger")

    db.session.delete(chapter)
    db.session.commit()

    return redirect(url_for('dashboard.admin_dashboard'))      


      