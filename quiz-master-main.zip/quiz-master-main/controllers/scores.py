from flask import Blueprint, render_template, flash , redirect , url_for , request
from flask_login import login_required , current_user
from models import db
from models.subjects import Subjects
from models.scores import Scores
from models.quizzes import Quizzes
from models.chapters import Chapters

scores_bp = Blueprint("scores", __name__) 


@scores_bp.route("/scores", methods=["GET"])
@login_required
def view_scores():
    user_scores = (
        db.session.query(Scores, Quizzes, Chapters)
        .join(Quizzes, Scores.quiz_id == Quizzes.id)
        .join(Chapters, Quizzes.chapter_id == Chapters.id)
        .filter(Scores.user_id == current_user.id)
        .order_by(Scores.time_stamp_of_attempt.desc())
        .all()
    )

    return render_template("scores.html", user_scores=user_scores)  